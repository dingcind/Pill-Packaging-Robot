import sys
if sys.version_info[0] == 2:  # the tkinter library changed it's name from Python 2 to 3.
    import Tkinter
    tkinter = Tkinter #I decided to use a library reference to avoid potential naming conflicts with people's programs.
else:
    import tkinter
from PIL import Image, ImageTk
import serial

def showPIL(pilImage):
    root = tkinter.Tk()
    w, h = root.winfo_screenwidth(), root.winfo_screenheight()
    root.overrideredirect(1)
    root.geometry("%dx%d+0+0" % (w, h))
    root.focus_set()
    root.bind("<Escape>", lambda e: (e.widget.withdraw(), e.widget.quit()))
    canvas = tkinter.Canvas(root,width=w,height=h)
    canvas.pack()
    canvas.configure(background='black')
    imgWidth, imgHeight = pilImage.size
    if imgWidth > w or imgHeight > h:
        ratio = min(w/imgWidth, h/imgHeight)
        imgWidth = int(imgWidth*ratio)
        imgHeight = int(imgHeight*ratio)
        pilImage = pilImage.resize((imgWidth,imgHeight), Image.ANTIALIAS)
    image = ImageTk.PhotoImage(pilImage)
    imagesprite = canvas.create_image(w/2,h/2,image=image)
    root.mainloop()

if __name__ == '__main__':
	arduinoSerial = serial.Serial("/dev/tty.usbmodem1421", 9600)
	position = 0

	while True:
		button = arduinoSerial.readline()
		if button == 'c':
			if position == 0:
				pilImage = Image.open("praxis0.png")
				showPIL(pilImage)
				position += 1
			if position == 1:
				pilImage = Image.open("praxis1.png")
				showPIL(pilImage)
				position += 1
			if position == 2:
				pilImage = Image.open("praxis2.png")
				showPIL(pilImage)
				position = 0
